CREATE PROCEDURE prologin(IN userName VARCHAR(50), IN userPwd VARCHAR(50), OUT rowCount INT)
  set rowCount=
(
	select count(*)
    from users 
    where LoginId=userName and LoginPwd =userPwd
);
