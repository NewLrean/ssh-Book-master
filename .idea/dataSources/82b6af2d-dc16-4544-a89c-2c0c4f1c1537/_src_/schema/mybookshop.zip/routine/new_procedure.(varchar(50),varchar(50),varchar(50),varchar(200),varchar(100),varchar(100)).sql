CREATE PROCEDURE new_procedure(IN username VARCHAR(50), IN userpwd VARCHAR(50), IN name1 VARCHAR(50),
                               IN address1 VARCHAR(200), IN phone1 VARCHAR(100), IN mail1 VARCHAR(100))
  BEGIN
insert into users(LoginId,loginpwd,Name,Address,phone,mail) 
values (username,userpwd,name1,address1,phone1,mail1);
END;
