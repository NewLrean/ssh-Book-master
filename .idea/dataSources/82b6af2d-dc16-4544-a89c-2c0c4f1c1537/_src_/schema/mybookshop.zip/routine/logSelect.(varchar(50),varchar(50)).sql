CREATE PROCEDURE logSelect(IN logId VARCHAR(50), IN pw VARCHAR(50), OUT resOut INT)
  BEGIN
SELECT COUNT(*) INTO resOut FROM `users` WHERE `LoginId` = logId AND `LoginPwd`=pw;
END;
